import { useState } from "react";
import { askQuestion } from "../services/api.js";
import SourceList from "./SourceList.jsx";

export default function ChatPanel({ selectedVideo, canAsk }) {
  const [question, setQuestion] = useState("");
  const [entries, setEntries] = useState([]);
  const [isAsking, setIsAsking] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(event) {
    event.preventDefault();
    const trimmed = question.trim();
    if (!trimmed || isAsking) return;

    setIsAsking(true);
    setError("");

    try {
      const result = await askQuestion(trimmed, selectedVideo ? selectedVideo.id : null);
      setEntries((prev) => [{ question: trimmed, ...result }, ...prev]);
      setQuestion("");
    } catch (err) {
      setError(err.message || "Something went wrong while asking that question.");
    } finally {
      setIsAsking(false);
    }
  }

  return (
    <div className="chat-panel">
      <div className="chat-scope">
        Asking about <strong>{selectedVideo ? selectedVideo.title : "all lectures"}</strong>
      </div>

      <form className="ask-form" onSubmit={handleSubmit}>
        <input
          type="text"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="What is supervised learning?"
          disabled={!canAsk || isAsking}
        />
        <button type="submit" disabled={!canAsk || isAsking || !question.trim()}>
          {isAsking ? "Asking…" : "Ask"}
        </button>
      </form>

      {!canAsk && (
        <p className="empty-note">Upload and process a lecture before asking questions.</p>
      )}

      {error && <p className="error-message">{error}</p>}

      <div className="entries">
        {entries.map((entry, i) => (
          <article className="entry" key={i}>
            <p className="entry-question">{entry.question}</p>
            <p className="entry-answer">{entry.answer}</p>
            <SourceList sources={entry.sources} />
          </article>
        ))}
      </div>
    </div>
  );
}
