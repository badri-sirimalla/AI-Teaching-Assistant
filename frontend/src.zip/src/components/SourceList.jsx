function formatTimestamp(seconds) {
  const total = Math.max(0, Math.round(seconds || 0));
  const mins = Math.floor(total / 60);
  const secs = total % 60;
  return `${mins}:${secs.toString().padStart(2, "0")}`;
}

export default function SourceList({ sources }) {
  if (!sources || sources.length === 0) return null;

  return (
    <div className="source-list">
      <h3 className="source-heading">Referenced in</h3>
      <div className="source-tags">
        {sources.map((source, i) => (
          <div className="source-tag" key={i}>
            <span className="source-tag-title">{source.title}</span>
            <span className="source-tag-time">
              {formatTimestamp(source.start)}–{formatTimestamp(source.end)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
